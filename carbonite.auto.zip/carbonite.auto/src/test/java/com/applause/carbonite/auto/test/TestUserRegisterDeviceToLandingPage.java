package com.applause.carbonite.auto.test;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.applause.auto.framework.pageframework.util.environment.LocatorKeyNotFoundException;
import com.applause.carbonite.auto.pageframework.testdata.CarboniteTestConstants;
import com.applause.carbonite.auto.pageframework.views.CarboniteLandingView;
import com.applause.carbonite.auto.pageframework.views.CarboniteLoginView;
import com.applause.carbonite.auto.pageframework.views.CarboniteNewUserView;
import com.applause.carbonite.auto.pageframework.views.CarboniteWelcomeView;
import com.applause.carbonite.auto.pageframework.views.CarboniteYoureReadyView;

public class TestUserRegisterDeviceToLandingPage extends
		CarboniteBaseAppiumTest {
	private Logger logger = Logger
			.getLogger(TestUserRegisterDeviceToLandingPage.class);

	private CarboniteNewUserView newUserView;
	private CarboniteLoginView loginView;
	private CarboniteWelcomeView welcomeView;
	private CarboniteLandingView landingView;
	private CarboniteYoureReadyView youreReadyView;

	@Test(groups = { CarboniteTestConstants.TestNGGroups.REG_DEVICE }, description = "Test ID")
	public void testUserLoginRegisterDeviceToLandingPage() {
		newUserView = new CarboniteNewUserView();
		loginView = newUserView.tapLoginButton();

		if (!env.getIsMobileIOS()) {

			welcomeView = loginView.doSuccessfulFirstLogin(
					CarboniteTestConstants.TestData.VALID_USER,
					CarboniteTestConstants.TestData.VALID_USER_PASSWORD);

			// turn protect off
			welcomeView.getProtectDeviceCheckbox().tap(); // tap ok on welcome
															// view
			youreReadyView = welcomeView.tapOk(); // tapok on you're ready view
			landingView = youreReadyView.tapOk();
		} else {
			landingView = loginView.doSuccessfulLogin(
					CarboniteTestConstants.TestData.VALID_USER,
					CarboniteTestConstants.TestData.VALID_USER_PASSWORD);
		}
		// assert that user is on landing page by getting device count > 1
		try {
			Assert.assertTrue(landingView.getRegisteredDeviceCount() > 1,
					"Expected Device Count on Landing Page to be greater then 1.");
		} catch (LocatorKeyNotFoundException e) {
			e.printStackTrace();
			Assert.fail("Exception occurred when getting Device count on carbonite landing page.");
		}

	}
}
