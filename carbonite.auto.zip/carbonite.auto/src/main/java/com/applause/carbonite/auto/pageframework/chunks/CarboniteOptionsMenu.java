package com.applause.carbonite.auto.pageframework.chunks;

import org.apache.log4j.Logger;

import com.applause.auto.framework.pageframework.device.AbstractDeviceView;
import com.applause.auto.framework.pageframework.devicecontrols.Link;
import com.applause.auto.framework.pageframework.util.environment.LocatorKeyNotFoundException;

/**
 * Class represents the Options Menu exposed by clicking the three dots on the
 * top bar.
 *
 */
public class CarboniteOptionsMenu extends AbstractDeviceView {
	private Logger logger = Logger.getLogger(CarboniteOptionsMenu.class);

	private Link logOutLink;
	private Link savedFilesLink;
	private Link settingsLink;
	private Link helpLink;
	private Link searchLink;

	/**
	 * Create a Option Menu
	 */
	public CarboniteOptionsMenu() {
		super();
		syncHelper.waitForElementToAppear(getHelpLink());
		syncHelper.waitForElementToAppear(getSavedFilesLink());
		snapshotManager.takeRemoteDeviceSnapShot("Options_Menu_", driver);
		logger.info("Created Options Menu.");
	}

	/**
	 * Tap Search Link and return a search chunk
	 * 
	 * @return
	 */
	public CarboniteSearchChunk tapSearchLink() {
		logger.info("Tapping Search");
		getSearchLink().tap();
		return new CarboniteSearchChunk();
	}

	/**
	 * @return the logOutLink
	 */
	public Link getLogOutLink() {
		try {
			logOutLink = new Link(
					env.getLocatorByName("OPTIONS_MENU_LOG_OUT_LINK"));
		} catch (LocatorKeyNotFoundException e) {
			e.printStackTrace();
		}
		return logOutLink;
	}

	/**
	 * @return the savedFilesLink
	 */
	public Link getSavedFilesLink() {
		try {
			savedFilesLink = new Link(
					env.getLocatorByName("OPTIONS_MENU_SAVED_FILES_LINK"));
		} catch (LocatorKeyNotFoundException e) {
			e.printStackTrace();
		}

		return savedFilesLink;
	}

	/**
	 * @return the settingsLink
	 */
	public Link getSettingsLink() {
		try {
			settingsLink = new Link(
					env.getLocatorByName("OPTIONS_MENU_SETTINGS_LINK"));
		} catch (LocatorKeyNotFoundException e) {
			e.printStackTrace();
		}
		return settingsLink;
	}

	/**
	 * @return the helpLink
	 */
	public Link getHelpLink() {
		try {
			helpLink = new Link(env.getLocatorByName("OPTIONS_MENU_HELP_LINK"));
		} catch (LocatorKeyNotFoundException e) {
			e.printStackTrace();
		}
		return helpLink;
	}

	/**
	 * @return the searchLink
	 */
	public Link getSearchLink() {
		try {
			searchLink = new Link(
					env.getLocatorByName("OPTIONS_MENU_SEARCH_LINK"));
		} catch (LocatorKeyNotFoundException e) {
			e.printStackTrace();
		}
		return searchLink;
	}

}
