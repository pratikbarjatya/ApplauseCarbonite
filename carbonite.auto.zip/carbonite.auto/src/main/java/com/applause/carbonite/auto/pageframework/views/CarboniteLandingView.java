package com.applause.carbonite.auto.pageframework.views;

import org.apache.log4j.Logger;

import com.applause.auto.framework.pageframework.device.AbstractDeviceView;
import com.applause.auto.framework.pageframework.devicecontrols.Button;
import com.applause.auto.framework.pageframework.devicecontrols.Text;
import com.applause.auto.framework.pageframework.util.Constants;
import com.applause.auto.framework.pageframework.util.environment.LocatorKeyNotFoundException;

public class CarboniteLandingView extends AbstractDeviceView {
	private Logger logger = Logger.getLogger(CarboniteLandingView.class);
	private Button addComputerBackupButton;
	private Button settingsButton;

	/**
	 * Create Carbonite device landing view
	 */
	public CarboniteLandingView() {
		super();
		if (env.getIsMobileIOS()) {
			// sync on settings button
			syncHelper.waitForElementToAppear(getSettingsButton());
		} else {
			// in android device - sync on add computer backup button
			syncHelper.waitForElementToAppear(getAddComputerBackupButton());

		}
		snapshotManager.takeRemoteDeviceSnapShot("Landing_View_", driver);
		logger.info("Created Landing View.");
	}

	/**
	 * @return device count on landing page
	 * @throws LocatorKeyNotFoundException
	 */
	public int getRegisteredDeviceCount() throws LocatorKeyNotFoundException {
		if (env.getIsMobileIOS()) {
			int count = queryHelper.getMobileElementCount(env
					.getLocatorByName("LANDING_VIEW_BACKUP_BUTTON"));
			int loopCount = 0;
			while ((count == 0) || (loopCount > 20)) {
				syncHelper.suspend(Constants.Waits.MEDIUM_WAIT_MILI);
				count = queryHelper.getMobileElementCount(env
						.getLocatorByName("LANDING_VIEW_BACKUP_BUTTON"));
				loopCount++;
			}
			return count;
		}
		// if not iOS, must be Android
		return queryHelper.getAndroidElementCount(env
				.getLocatorByName("LANDING_VIEW_DEVICE_ICON"));
	}

	/**
	 * Get the index of the device c
	 * 
	 * @param title
	 * @return
	 */
	public int getIndexOfBackupAndProtectChunkWithTitle(String title) {
		int index = 0;
		try {
			int visibleCount = queryHelper.getAndroidElementCount(env
					.getLocatorByName("BACKUP_PROTECTION_CHUNK_GENERAL"));
			for (int i = 0; i < visibleCount; i++) {
				Text deviceTitle = new Text(
						String.format(
								env.getLocatorByName("BACKUP_PROTECTION_CHUNK_DEVICE_TITLE"),
								i));
				logger.info(String.format("Compared [%s] to [%s]",
						deviceTitle.getStringValue(), title));
				if (deviceTitle.getStringValue().equals(title)) {

					return index;
				}
			}
		} catch (LocatorKeyNotFoundException e) {
			logger.error("Expception thrown when locating element.");
			e.printStackTrace();
		}

		return -1;
	}

	/**
	 * @return the addComputerBackupButton
	 */
	public Button getAddComputerBackupButton() {
		try {
			addComputerBackupButton = new Button(
					env.getLocatorByName("LANDING_VIEW_ADD_COMPUTER_BACKUP_BUTTON"));
		} catch (LocatorKeyNotFoundException e) {
			e.printStackTrace();
		}
		return addComputerBackupButton;
	}

	/**
	 * @return the settingsButton
	 */
	public Button getSettingsButton() {
		try {
			settingsButton = new Button(
					env.getLocatorByName("LANDING_VIEW_SETTINGS_BUTTON"));
		} catch (LocatorKeyNotFoundException e) {
			e.printStackTrace();
		}
		return settingsButton;
	}
}
