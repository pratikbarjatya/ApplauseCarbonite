package com.applause.carbonite.auto.pageframework.testdata;

public class CarboniteTestConstants {

	/**
	 * Test Groups
	 */
	public final class TestNGGroups {
		public static final String BROWSE = "browse";

		public static final String SEARCH = "search";

		public static final String REG_DEVICE = "reg-device";

	}

	/**
	 * Test Data for tests
	 */
	public final class TestData {

		public static final String VALID_USER = "brock@applausemail.com";

		public static final String VALID_USER_PASSWORD = "password";
	}
}
